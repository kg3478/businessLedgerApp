# Business Ledger Application

A comprehensive digital ledger application for manufacturing businesses to replace physical records.

## Features

- Authentication system with login/register
- Party management for tracking business relationships 
- Transaction system for recording credits and deposits
- Bill upload and management integrated with transactions
- Dashboard with overview metrics and quick actions

## Setup Instructions

1. Install dependencies:
   ```
   npm install
   ```

2. Start the development server:
   ```
   npm run dev
   ```

3. Navigate to http://localhost:5000 in your browser

## User Guide

1. Register a new account from the auth page
2. After login, you'll be redirected to the dashboard
3. Create business parties using the "Manage Parties" section
4. Record transactions (credits/deposits) for each party
5. Upload and associate bills with transactions
6. Monitor outstanding balances and party activities

## Tech Stack

- Frontend: React, TailwindCSS, ShadcnUI
- Backend: Node.js, Express
- Database: In-memory storage (can be upgraded to PostgreSQL)
- Authentication: Session-based with Passport.js
